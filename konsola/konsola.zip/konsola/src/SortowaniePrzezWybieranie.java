import java.util.Scanner;

public class SortowaniePrzezWybieranie {
    private int[] tablica = new int[10];

    public static void main(String[] args) {
        SortowaniePrzezWybieranie sorter = new SortowaniePrzezWybieranie();
        sorter.wczytajTablice();
        sorter.posortujMalejaco();
        sorter.wyswietlTablice();
    }

    private void wczytajTablice(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Wprowadź 10 liczb całkowitych");

        for (int i = 0; i < tablica.length; i++){
            System.out.print("Liczba " + (i + 1) + ": ");
            tablica[i] = scanner.nextInt();
        }
    }

    /**
     * nazwa funkcji: posortujMalejaco
     * parametry wejściowe: brak
     * wartość zwracana: brak
     * autor: 00000000000
     **/
    private void posortujMalejaco(){
        for (int i = 0; i < tablica.length - 1; i++){
            int indeksMaks = znajdzIndeksMaksymalnejWartosci(i);
            zamien(i, indeksMaks);
        }
    }

    /**
     * nazwa funkcji: znajdzIndeksMaksymalnejWartosci
     * parametry wejściowe: start - początkowy indeks podtablicy
     * wartość zwracana: indeks największej wartości w podtablicy
     * autor: 00000000000
     **/

    private int znajdzIndeksMaksymalnejWartosci(int start){
        int indeksMaks = start;
        for (int i = start + 1; i < tablica.length; i++){
            if (tablica[i] > tablica[indeksMaks]){
                indeksMaks = i;
            }
        }
        return indeksMaks;
    }

    private void zamien(int i, int j){
        int temp = tablica[i];
        tablica[i] = tablica[j];
        tablica[j] = temp;
    }

    private void wyswietlTablice(){
        System.out.println("Posortowana tablica malejąco: ");
        for (int i : tablica){
            System.out.print(i + " ");
        }
    }
}