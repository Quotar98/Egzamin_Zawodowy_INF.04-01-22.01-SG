package com.example.mobilna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText emailEditText;
    EditText hasloEditText;
    EditText powtorzhasloEditText;
    TextView komunikatEditText;
    Button zatwierdzButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailEditText = findViewById(R.id.emailEditText);
        hasloEditText = findViewById(R.id.hasloEditText);
        powtorzhasloEditText = findViewById(R.id.powtorzhasloEditText);
        komunikatEditText = findViewById(R.id.komunikatEditText);
        zatwierdzButton = findViewById(R.id.zatwierdzButton);

        komunikatEditText.setText("Autor: 00000000000");

        zatwierdzButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sprawdzDane();
            }
        });

    }
    private void sprawdzDane(){
        String email= emailEditText.getText().toString().trim();
        String haslo = hasloEditText.getText().toString();
        String powtorzHaslo = powtorzhasloEditText.getText().toString();

        if(!jestPoprawnyEmail(email)){
            komunikatEditText.setText("Nieprawidłowy adres e-mail");
            return;
        }

        if (!haslaSaRowne(haslo, powtorzHaslo)){
            komunikatEditText.setText("Hasła się różnią");
            return;
        }

        komunikatEditText.setText("Witaj " + email);

    }
    private boolean jestPoprawnyEmail(String email) {
        return email.contains("@");
    }

    private boolean haslaSaRowne(String haslo, String powtorzHaslo){
        return haslo.equals(powtorzHaslo);
    }

}